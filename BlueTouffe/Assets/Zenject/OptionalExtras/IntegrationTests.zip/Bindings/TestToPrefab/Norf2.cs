using System;
using UnityEngine;

namespace ModestTree.Tests.Zenject.ToPrefab
{
    public class Norf2 : MonoBehaviour, INorf
    {
    }
}

