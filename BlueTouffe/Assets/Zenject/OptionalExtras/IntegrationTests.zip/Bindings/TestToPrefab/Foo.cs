﻿using UnityEngine;

namespace ModestTree.Tests.Zenject.ToPrefab
{
    public interface IFoo
    {
    }

    public class Foo : MonoBehaviour, IFoo
    {
    }
}
