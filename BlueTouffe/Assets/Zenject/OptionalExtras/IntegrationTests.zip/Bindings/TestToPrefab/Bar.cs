﻿using UnityEngine;

namespace ModestTree.Tests.Zenject.ToPrefab
{
    public class Bar : MonoBehaviour
    {
    }
}
