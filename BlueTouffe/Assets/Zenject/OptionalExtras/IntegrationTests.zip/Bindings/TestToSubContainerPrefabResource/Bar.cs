using UnityEngine;

namespace ModestTree.Tests.Zenject.ToSubContainerPrefabResource
{
    public class Bar : MonoBehaviour
    {
    }
}

