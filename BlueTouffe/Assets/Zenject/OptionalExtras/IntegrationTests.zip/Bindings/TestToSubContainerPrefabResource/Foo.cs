﻿using UnityEngine;

namespace ModestTree.Tests.Zenject.ToSubContainerPrefabResource
{
    public interface IFoo
    {
    }

    public class Foo : MonoBehaviour, IFoo
    {
    }
}
