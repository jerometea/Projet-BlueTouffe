﻿using UnityEngine;

namespace ModestTree.Tests.Zenject.ToTransientPrefab
{
    public interface IFoo
    {
    }

    public class Foo : MonoBehaviour, IFoo
    {
    }
}
