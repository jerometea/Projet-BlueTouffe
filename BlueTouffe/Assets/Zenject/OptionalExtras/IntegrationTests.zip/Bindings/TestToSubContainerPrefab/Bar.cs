using UnityEngine;

namespace ModestTree.Tests.Zenject.ToSubContainerPrefab
{
    public class Bar : MonoBehaviour
    {
    }
}

