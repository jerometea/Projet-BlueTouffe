﻿using UnityEngine;

namespace ModestTree.Tests.Zenject.ToSubContainerPrefab
{
    public interface IFoo
    {
    }

    public class Foo : MonoBehaviour, IFoo
    {
    }
}
