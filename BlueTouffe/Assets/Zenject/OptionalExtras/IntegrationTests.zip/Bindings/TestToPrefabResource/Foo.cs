﻿using UnityEngine;

namespace ModestTree.Tests.Zenject.ToPrefabResource
{
    public interface IFoo
    {
    }

    public class Foo : MonoBehaviour, IFoo
    {
    }
}
