﻿using UnityEngine;

namespace ModestTree.Tests.Zenject.ToPrefabResource
{
    public class Bar : MonoBehaviour
    {
    }
}
