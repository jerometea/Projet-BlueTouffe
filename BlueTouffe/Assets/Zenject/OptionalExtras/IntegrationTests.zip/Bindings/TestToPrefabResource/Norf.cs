using System;
using UnityEngine;

namespace ModestTree.Tests.Zenject.ToPrefabResource
{
    public interface INorf
    {
    }

    public class Norf : MonoBehaviour, INorf
    {
    }
}
